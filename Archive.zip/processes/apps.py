from django.apps import AppConfig


class ProcessesConfig(AppConfig):
    name = 'processes'
