# Post production control platform

This web platform is for entering the products of the factory into the system and keeping records in different processes.

Dashboard is developed to follow up post production organizations, controls and statistics.

This website will be used at the factory

![Screen Shot 2020-03-30 at 14 42 27](https://user-images.githubusercontent.com/63015466/78178545-7f563b80-7468-11ea-8170-5c35170fbeb0.png)
