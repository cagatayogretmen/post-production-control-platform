from django.contrib import admin
from .models import deneme


admin.site.register(deneme)